COMPONENT_STATE_COLORS = {
    'Waiting': 'black',
    'RapidInspection': 'lightblue',
    'Financing': 'orange',
    'ContractorMobilization': 'springgreen',
    'SitePreparation': 'purple',
    'CleanUp': 'yellow',
    'DetailedInspection': 'tomato',
    'ArchAndEngDesign': 'pink',
    'Permitting': 'darkblue',
    'Demolition': 'gray',
    'Repair': 'red',
    'Functional': 'green'
}