__version__ = "0.2.0"
__author__ = 'Nikola Blagojevic and Bozidar Stojadinovic'