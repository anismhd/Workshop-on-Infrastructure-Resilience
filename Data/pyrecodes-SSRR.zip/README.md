# pyrecodes
Software for regional recovery simulation and resilience assessment of the built environment based on the iRe-CoDeS framework.

For more details, please visit: https://nikolablagojevic.github.io/pyrecodes/html/usage/what_is_pyrecodes.html
